// Simple Deno server for serving React SPA
const PORT = Deno.env.get("PORT") || "8000";

async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const pathname = url.pathname;

  try {
    // Handle static assets
    if (pathname.startsWith("/assets/") || pathname === "/vite.svg") {
      const filePath = `./dist${pathname}`;
      try {
        const file = await Deno.readFile(filePath);
        const ext = pathname.split('.').pop();
        const contentType = ext === 'js' ? 'application/javascript' : 
                           ext === 'css' ? 'text/css' : 
                           ext === 'svg' ? 'image/svg+xml' : 'text/plain';
        
        return new Response(file, {
          headers: { "content-type": contentType }
        });
      } catch {
        return new Response("Not Found", { status: 404 });
      }
    }

    // For all other routes, serve index.html (SPA routing)
    const indexFile = await Deno.readFile("./dist/index.html");
    return new Response(indexFile, {
      headers: { "content-type": "text/html" }
    });

  } catch (error) {
    console.error("Server error:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
}

console.log(`Server running on port ${PORT}`);
Deno.serve({ port: parseInt(PORT) }, handler);