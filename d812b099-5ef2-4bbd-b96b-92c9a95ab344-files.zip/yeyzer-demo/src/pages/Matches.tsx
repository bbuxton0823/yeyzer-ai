import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Sparkles,
  Bell,
  Settings,
  Search,
  Filter,
  MapPin,
  MessageSquare,
  Calendar,
  Heart,
  X,
  RefreshCw,
  Send,
  Map,
  Clock,
  Coffee
} from 'lucide-react';
import { toast } from 'sonner';

// Extended mock data for matches
const allMatches = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Product Manager',
    company: 'TechCorp',
    matchScore: 94,
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b1a7?w=150&h=150&fit=crop&crop=face',
    tags: ['AI/ML', 'Product Strategy', 'B2B SaaS'],
    icebreaker: "I noticed you're both passionate about AI in product development. Sarah recently led the implementation of ML features at TechCorp.",
    location: 'San Francisco, CA',
    status: 'new'
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    role: 'Engineering Lead',
    company: 'DataFlow',
    matchScore: 89,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    tags: ['Backend', 'Scalability', 'DevOps'],
    icebreaker: "Both of you have extensive experience with distributed systems. Marcus recently scaled DataFlow's infrastructure to handle 10M+ requests.",
    location: 'Austin, TX',
    status: 'chatting'
  },
  {
    id: '3',
    name: 'Emma Rodriguez',
    role: 'Startup Founder',
    company: 'GreenTech Solutions',
    matchScore: 87,
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    tags: ['Sustainability', 'Climate Tech', 'Fundraising'],
    icebreaker: "Your shared interest in climate technology could lead to interesting collaboration opportunities. Emma is raising Series A for her climate startup.",
    location: 'New York, NY',
    status: 'scheduled'
  },
  {
    id: '4',
    name: 'David Park',
    role: 'UX Director',
    company: 'DesignCo',
    matchScore: 85,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face',
    tags: ['Design Systems', 'User Research', 'Mobile UX'],
    icebreaker: "Both of you share a passion for user-centered design. David recently launched a design system that improved user satisfaction by 40%.",
    location: 'Seattle, WA',
    status: 'new'
  },
  {
    id: '5',
    name: 'Lisa Wang',
    role: 'Data Scientist',
    company: 'Analytics Pro',
    matchScore: 83,
    avatar: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&h=150&fit=crop&crop=face',
    tags: ['Machine Learning', 'Data Visualization', 'Python'],
    icebreaker: "Your complementary skills in ML and engineering could create powerful solutions. Lisa specializes in building production ML pipelines.",
    location: 'Boston, MA',
    status: 'new'
  },
  {
    id: '6',
    name: 'James Wilson',
    role: 'Sales Director',
    company: 'Revenue Inc',
    matchScore: 81,
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&h=150&fit=crop&crop=face',
    tags: ['B2B Sales', 'Go-to-Market', 'SaaS'],
    icebreaker: "Both of you understand the importance of technical-sales alignment. James has consistently exceeded revenue targets through product-focused selling.",
    location: 'Chicago, IL',
    status: 'declined'
  }
];

// Mock chat messages
const mockChatMessages = {
  '1': [
    { sender: 'Sarah Chen', message: "Hi! Thanks for connecting. I'm excited to discuss AI applications in product development!", time: '2 min ago' },
    { sender: 'You', message: "Great to meet you Sarah! I saw your recent work on ML features at TechCorp. How did you approach the initial implementation?", time: '1 min ago' },
    { sender: 'Sarah Chen', message: "We started with user behavior prediction and gradually expanded. The key was getting buy-in from engineering early on. Would love to share more details over coffee!", time: 'Just now' }
  ],
  '2': [
    { sender: 'Marcus Johnson', message: "Hey! Saw your profile and really impressed by your distributed systems work.", time: '5 min ago' },
    { sender: 'You', message: "Thanks Marcus! I'd love to hear about how you scaled DataFlow to 10M+ requests. That's incredible growth.", time: '3 min ago' },
    { sender: 'Marcus Johnson', message: "It was quite a journey! Started with microservices architecture and auto-scaling. Happy to dive deeper if you're interested in grabbing lunch.", time: '1 min ago' }
  ]
};

// Mock meeting locations
const mockLocations = {
  'San Francisco, CA': [
    { name: 'Blue Bottle Coffee', address: '66 Mint St, San Francisco', type: 'coffee', rating: 4.4 },
    { name: 'Philz Coffee', address: '201 Berry St, San Francisco', type: 'coffee', rating: 4.3 },
    { name: 'The Plant Café Organic', address: 'Pier 3, San Francisco', type: 'restaurant', rating: 4.2 }
  ],
  'Austin, TX': [
    { name: 'Radio Coffee & Beer', address: '4204 Menchaca Rd, Austin', type: 'coffee', rating: 4.5 },
    { name: 'Sour Duck Market', address: '1814 E Martin Luther King Jr Blvd, Austin', type: 'restaurant', rating: 4.4 },
    { name: 'Mozart\'s Coffee Roasters', address: '3825 Lake Austin Blvd, Austin', type: 'coffee', rating: 4.3 }
  ],
  'New York, NY': [
    { name: 'Blue Stone Lane', address: '90 Greenwich Ave, New York', type: 'coffee', rating: 4.4 },
    { name: 'Jack\'s Wife Freda', address: '224 Lafayette St, New York', type: 'restaurant', rating: 4.3 },
    { name: 'Bluestone Lane', address: '30 Broad St, New York', type: 'coffee', rating: 4.2 }
  ]
};

export function Matches() {
  const { user, logout } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('score');
  const [matchStatuses, setMatchStatuses] = useState<Record<string, string>>(
    Object.fromEntries(allMatches.map(match => [match.id, match.status]))
  );
  const [loadingStates, setLoadingStates] = useState<Record<string, boolean>>({});
  const [showChatDialog, setShowChatDialog] = useState(false);
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<any>(null);
  const [chatMessage, setChatMessage] = useState('');

  const filteredMatches = allMatches
    .filter(match => {
      const matchesSearch = searchTerm === '' || 
        match.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        match.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
        match.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
        match.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const currentStatus = matchStatuses[match.id] || match.status;
      const matchesStatus = statusFilter === 'all' || currentStatus === statusFilter;
      
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      if (sortBy === 'score') return b.matchScore - a.matchScore;
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      return 0;
    });

  const handleStartChat = async (matchId: string, matchName: string) => {
    setLoadingStates(prev => ({ ...prev, [matchId]: true }));
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setMatchStatuses(prev => ({ ...prev, [matchId]: 'chatting' }));
      
      // Open chat dialog
      const match = allMatches.find(m => m.id === matchId);
      setSelectedMatch(match);
      setShowChatDialog(true);
      
      toast.success(`Chat started with ${matchName}!`, {
        description: "You can now send messages and share your icebreaker."
      });
    } catch (error) {
      toast.error("Failed to start chat", {
        description: "Please try again later."
      });
    } finally {
      setLoadingStates(prev => ({ ...prev, [matchId]: false }));
    }
  };

  const handleContinueChat = (match: any) => {
    setSelectedMatch(match);
    setShowChatDialog(true);
  };

  const handleScheduleMeeting = (match: any) => {
    setSelectedMatch(match);
    setShowMeetingDialog(true);
  };

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      toast.success("Message sent!", {
        description: `Your message to ${selectedMatch?.name} has been delivered.`
      });
      setChatMessage('');
    }
  };

  const handleSelectMeetingLocation = (location: any) => {
    toast.success(`Meeting request sent!`, {
      description: `You've suggested meeting at ${location.name}. ${selectedMatch?.name} will receive a notification to confirm.`
    });
    setShowMeetingDialog(false);
  };

  const handleDeclineMatch = (matchId: string, matchName: string) => {
    setMatchStatuses(prev => ({ ...prev, [matchId]: 'declined' }));
    toast.info(`Declined match with ${matchName}`, {
      description: "You won't see this person in your matches anymore."
    });
  };

  const handleFindNewMatches = () => {
    toast.info("🔍 Searching for new matches...", {
      description: "Our AI is analyzing your profile to find the best professional connections."
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'chatting': return 'bg-green-100 text-green-800';
      case 'scheduled': return 'bg-purple-100 text-purple-800';
      case 'declined': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'new': return <Heart className="h-3 w-3" />;
      case 'chatting': return <MessageSquare className="h-3 w-3" />;
      case 'scheduled': return <Calendar className="h-3 w-3" />;
      case 'declined': return <X className="h-3 w-3" />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link to="/dashboard" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-primary to-primary/60 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
                Yeyzer AI
              </span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <Link to="/dashboard" className="text-muted-foreground hover:text-foreground">
                Dashboard
              </Link>
              <Link to="/matches" className="font-medium text-primary">
                Matches
              </Link>
              <Link to="/profile" className="text-muted-foreground hover:text-foreground">
                Profile
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <Link to="/settings">
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user?.firstName?.[0]}{user?.lastName?.[0]}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{user?.firstName}</span>
            </div>
            <Button variant="ghost" onClick={logout} className="text-sm">
              Sign Out
            </Button>
          </div>
        </div>
      </nav>

      <div className="container py-8 space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Your Matches</h1>
            <p className="text-muted-foreground">
              Discover professionals who align with your goals and interests
            </p>
          </div>
          <Button onClick={handleFindNewMatches}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Find New Matches
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search by name, role, company, or skills..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="flex gap-4">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="chatting">Chatting</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="score">Match Score</SelectItem>
                    <SelectItem value="name">Name</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Matches Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredMatches.map((match) => {
            const currentStatus = matchStatuses[match.id] || match.status;
            const isLoading = loadingStates[match.id];
            
            return (
              <Card key={match.id} className="border-2 hover:border-primary/20 transition-colors cursor-pointer">
                <CardHeader className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={match.avatar} alt={match.name} />
                        <AvatarFallback>{match.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{match.name}</CardTitle>
                        <CardDescription>{match.role} at {match.company}</CardDescription>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant="secondary" className="bg-primary/10 text-primary">
                        <Heart className="h-3 w-3 mr-1" />
                        {match.matchScore}%
                      </Badge>
                      <Badge className={getStatusColor(currentStatus)}>
                        {getStatusIcon(currentStatus)}
                        <span className="ml-1 capitalize">{currentStatus}</span>
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {match.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-foreground/70">
                    <MapPin className="h-4 w-4" />
                    {match.location}
                  </div>
                  
                  <div className="bg-primary/5 border border-primary/20 p-3 rounded-lg">
                    <p className="text-sm font-medium mb-1 text-primary">AI Icebreaker:</p>
                    <p className="text-sm text-foreground">{match.icebreaker}</p>
                  </div>
                  
                  <div className="flex gap-2">
                    {currentStatus === 'new' ? (
                      <>
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={() => handleStartChat(match.id, match.name)}
                          disabled={isLoading}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          {isLoading ? 'Starting...' : 'Start Chat'}
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleDeclineMatch(match.id, match.name)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </>
                    ) : currentStatus === 'chatting' ? (
                      <>
                        <Button 
                          size="sm" 
                          className="flex-1"
                          onClick={() => handleContinueChat(match)}
                        >
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Continue Chat
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleScheduleMeeting(match)}
                        >
                          <Calendar className="h-4 w-4 mr-2" />
                          Schedule
                        </Button>
                      </>
                    ) : currentStatus === 'scheduled' ? (
                      <Button size="sm" className="w-full" variant="outline">
                        <Calendar className="h-4 w-4 mr-2" />
                        Meeting Scheduled
                      </Button>
                    ) : (
                      <Button size="sm" className="w-full" variant="outline" disabled>
                        <X className="h-4 w-4 mr-2" />
                        Declined
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredMatches.length === 0 && (
          <div className="text-center py-12">
            <div className="h-24 w-24 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Search className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No matches found</h3>
            <p className="text-muted-foreground mb-4">
              Try adjusting your search or filters to find more matches.
            </p>
            <Button onClick={() => { setSearchTerm(''); setStatusFilter('all'); }}>
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Chat Dialog */}
      <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={selectedMatch?.avatar} alt={selectedMatch?.name} />
                <AvatarFallback>{selectedMatch?.name?.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
              </Avatar>
              Chat with {selectedMatch?.name}
            </DialogTitle>
            <DialogDescription>
              {selectedMatch?.role} at {selectedMatch?.company} • {selectedMatch?.location}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-primary/5 border border-primary/20 p-3 rounded-lg">
              <p className="text-sm font-medium text-primary mb-1">AI Icebreaker Suggestion:</p>
              <p className="text-sm text-foreground">{selectedMatch?.icebreaker}</p>
            </div>
            
            <div className="h-64 border rounded-lg p-4 overflow-y-auto bg-gray-50">
              {mockChatMessages[selectedMatch?.id as keyof typeof mockChatMessages]?.map((msg, idx) => (
                <div key={idx} className={`mb-3 flex ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs px-3 py-2 rounded-lg ${
                    msg.sender === 'You' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-white border text-foreground'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                    <p className={`text-xs mt-1 ${
                      msg.sender === 'You' ? 'text-primary-foreground/70' : 'text-muted-foreground'
                    }`}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Meeting Dialog */}
      <Dialog open={showMeetingDialog} onOpenChange={setShowMeetingDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Map className="h-5 w-5" />
              Suggest Meeting Location
            </DialogTitle>
            <DialogDescription>
              Choose a location to meet with {selectedMatch?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-sm text-foreground/70 flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Suggestions near {selectedMatch?.location}
            </div>
            
            <div className="space-y-2">
              {mockLocations[selectedMatch?.location as keyof typeof mockLocations]?.map((location, idx) => (
                <div
                  key={idx}
                  className="border rounded-lg p-3 hover:bg-primary/5 cursor-pointer transition-colors"
                  onClick={() => handleSelectMeetingLocation(location)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        {location.type === 'coffee' ? (
                          <Coffee className="h-4 w-4 text-amber-600" />
                        ) : (
                          <Clock className="h-4 w-4 text-green-600" />
                        )}
                        <h4 className="font-medium text-foreground">{location.name}</h4>
                      </div>
                      <p className="text-sm text-foreground/70 mt-1">{location.address}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-xs text-amber-600">★</span>
                        <span className="text-xs text-foreground/70">{location.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-xs text-foreground/50 text-center">
              💡 Tip: These locations are suggested based on proximity and ratings
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}