import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Users, 
  MessageSquare, 
  MapPin, 
  Calendar,
  TrendingUp,
  Heart,
  ArrowRight,
  Sparkles,
  Bell,
  Settings,
  Send,
  Map,
  Clock,
  Coffee
} from 'lucide-react';
import { toast } from 'sonner';

// Mock data for demo
const mockMatches = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'Product Manager',
    company: 'TechCorp',
    matchScore: 94,
    avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b1a7?w=150&h=150&fit=crop&crop=face',
    tags: ['AI/ML', 'Product Strategy', 'B2B SaaS'],
    icebreaker: "I noticed you're both passionate about AI in product development. Sarah recently led the implementation of ML features at TechCorp.",
    location: 'San Francisco, CA'
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    role: 'Engineering Lead',
    company: 'DataFlow',
    matchScore: 89,
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
    tags: ['Backend', 'Scalability', 'DevOps'],
    icebreaker: "Both of you have extensive experience with distributed systems. Marcus recently scaled DataFlow's infrastructure to handle 10M+ requests.",
    location: 'Austin, TX'
  },
  {
    id: '3',
    name: 'Emma Rodriguez',
    role: 'Startup Founder',
    company: 'GreenTech Solutions',
    matchScore: 87,
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face',
    tags: ['Sustainability', 'Climate Tech', 'Fundraising'],
    icebreaker: "Your shared interest in climate technology could lead to interesting collaboration opportunities. Emma is raising Series A for her climate startup.",
    location: 'New York, NY'
  }
];

const stats = [
  { label: 'Total Matches', value: '24', icon: Users, change: '+3 this week' },
  { label: 'Active Conversations', value: '8', icon: MessageSquare, change: '+2 new' },
  { label: 'Meetings Scheduled', value: '3', icon: Calendar, change: 'This month' },
  { label: 'Match Success Rate', value: '89%', icon: TrendingUp, change: '+5% improvement' },
];

// Mock chat messages
const mockChatMessages = {
  '1': [
    { sender: 'Sarah Chen', message: "Hi! Thanks for connecting. I'm excited to discuss AI applications in product development!", time: '2 min ago' },
    { sender: 'You', message: "Great to meet you Sarah! I saw your recent work on ML features at TechCorp. How did you approach the initial implementation?", time: '1 min ago' },
    { sender: 'Sarah Chen', message: "We started with user behavior prediction and gradually expanded. The key was getting buy-in from engineering early on. Would love to share more details over coffee!", time: 'Just now' }
  ],
  '2': [
    { sender: 'Marcus Johnson', message: "Hey! Saw your profile and really impressed by your distributed systems work.", time: '5 min ago' },
    { sender: 'You', message: "Thanks Marcus! I'd love to hear about how you scaled DataFlow to 10M+ requests. That's incredible growth.", time: '3 min ago' },
    { sender: 'Marcus Johnson', message: "It was quite a journey! Started with microservices architecture and auto-scaling. Happy to dive deeper if you're interested in grabbing lunch.", time: '1 min ago' }
  ],
  '3': [
    { sender: 'Emma Rodriguez', message: "Hi there! Great to connect with another person passionate about climate tech!", time: '10 min ago' },
    { sender: 'You', message: "Emma! I'm fascinated by your work at GreenTech Solutions. How's the Series A fundraising going?", time: '8 min ago' },
    { sender: 'Emma Rodriguez', message: "It's been exciting! We're seeing strong investor interest in climate solutions. Would love to discuss potential collaboration opportunities - maybe over lunch in NYC?", time: '5 min ago' }
  ]
};

// Mock meeting locations
const mockLocations = {
  'San Francisco, CA': [
    { name: 'Blue Bottle Coffee', address: '66 Mint St, San Francisco', type: 'coffee', rating: 4.4 },
    { name: 'Philz Coffee', address: '201 Berry St, San Francisco', type: 'coffee', rating: 4.3 },
    { name: 'The Plant Café Organic', address: 'Pier 3, San Francisco', type: 'restaurant', rating: 4.2 }
  ],
  'Austin, TX': [
    { name: 'Radio Coffee & Beer', address: '4204 Menchaca Rd, Austin', type: 'coffee', rating: 4.5 },
    { name: 'Sour Duck Market', address: '1814 E Martin Luther King Jr Blvd, Austin', type: 'restaurant', rating: 4.4 },
    { name: 'Mozart\'s Coffee Roasters', address: '3825 Lake Austin Blvd, Austin', type: 'coffee', rating: 4.3 }
  ],
  'New York, NY': [
    { name: 'Blue Stone Lane', address: '90 Greenwich Ave, New York', type: 'coffee', rating: 4.4 },
    { name: 'Jack\'s Wife Freda', address: '224 Lafayette St, New York', type: 'restaurant', rating: 4.3 },
    { name: 'Bluestone Lane', address: '30 Broad St, New York', type: 'coffee', rating: 4.2 }
  ]
};

export function Dashboard() {
  const { user, logout } = useAuth();
  const [chatStates, setChatStates] = useState<Record<string, 'idle' | 'starting' | 'active'>>({});
  const [showChatDialog, setShowChatDialog] = useState(false);
  const [showMeetingDialog, setShowMeetingDialog] = useState(false);
  const [selectedMatch, setSelectedMatch] = useState<any>(null);
  const [chatMessage, setChatMessage] = useState('');

  const handleStartChat = async (matchId: string, matchName: string) => {
    // Set loading state
    setChatStates(prev => ({ ...prev, [matchId]: 'starting' }));
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update state to show chat is active
      setChatStates(prev => ({ ...prev, [matchId]: 'active' }));
      
      // Show success notification
      toast.success(`Chat started with ${matchName}!`, {
        description: "You can now send messages and share your icebreaker."
      });
      
      // Open chat dialog
      const match = mockMatches.find(m => m.id === matchId);
      setSelectedMatch(match);
      setShowChatDialog(true);
      
    } catch (error) {
      // Handle error
      setChatStates(prev => ({ ...prev, [matchId]: 'idle' }));
      toast.error("Failed to start chat", {
        description: "Please try again or contact support if the issue persists."
      });
    }
  };

  const handleSuggestMeeting = (match: any) => {
    setSelectedMatch(match);
    setShowMeetingDialog(true);
  };

  const handleSendMessage = () => {
    if (chatMessage.trim()) {
      toast.success("Message sent!", {
        description: `Your message to ${selectedMatch?.name} has been delivered.`
      });
      setChatMessage('');
    }
  };

  const handleSelectMeetingLocation = (location: any) => {
    toast.success(`Meeting request sent!`, {
      description: `You've suggested meeting at ${location.name}. ${selectedMatch?.name} will receive a notification to confirm.`
    });
    setShowMeetingDialog(false);
  };

  const getButtonText = (matchId: string) => {
    const state = chatStates[matchId];
    switch (state) {
      case 'starting': return 'Starting...';
      case 'active': return 'Open Chat';
      default: return 'Start Chat';
    }
  };

  const isButtonDisabled = (matchId: string) => {
    return chatStates[matchId] === 'starting';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link to="/dashboard" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-gradient-to-r from-primary to-primary/60 flex items-center justify-center">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
                Yeyzer AI
              </span>
            </Link>
            
            <nav className="hidden md:flex items-center gap-6 text-sm">
              <Link to="/dashboard" className="font-medium text-primary">
                Dashboard
              </Link>
              <Link to="/matches" className="text-muted-foreground hover:text-foreground">
                Matches
              </Link>
              <Link to="/profile" className="text-muted-foreground hover:text-foreground">
                Profile
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4" />
            </Button>
            <Link to="/settings">
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarFallback>{user?.firstName?.[0]}{user?.lastName?.[0]}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{user?.firstName}</span>
            </div>
            <Button variant="ghost" onClick={logout} className="text-sm">
              Sign Out
            </Button>
          </div>
        </div>
      </nav>

      <div className="container py-8 space-y-8">
        {/* Welcome Section */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">
            Welcome back, {user?.firstName}!
          </h1>
          <p className="text-muted-foreground">
            Here's what's happening with your professional network today.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.label}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.label}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  {stat.change}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Recent Matches */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">Your Top Matches</h2>
            <Link to="/matches">
              <Button variant="outline">
                View All Matches <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {mockMatches.map((match) => (
              <Card key={match.id} className="border-2 hover:border-primary/20 transition-colors cursor-pointer">
                <CardHeader className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={match.avatar} alt={match.name} />
                        <AvatarFallback>{match.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{match.name}</CardTitle>
                        <CardDescription>{match.role} at {match.company}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-primary/10 text-primary">
                      <Heart className="h-3 w-3 mr-1" />
                      {match.matchScore}%
                    </Badge>
                  </div>
                  
                  <div className="flex flex-wrap gap-1">
                    {match.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-foreground/70">
                    <MapPin className="h-4 w-4" />
                    {match.location}
                  </div>
                  
                  <div className="bg-primary/5 border border-primary/20 p-3 rounded-lg">
                    <p className="text-sm font-medium mb-1 text-primary">AI Icebreaker:</p>
                    <p className="text-sm text-foreground">{match.icebreaker}</p>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      className="flex-1" 
                      onClick={() => handleStartChat(match.id, match.name)}
                      disabled={isButtonDisabled(match.id)}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      {getButtonText(match.id)}
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleSuggestMeeting(match)}
                    >
                      <MapPin className="h-4 w-4 mr-2" />
                      Suggest Meeting
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Common tasks to help you make the most of your networking
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Link to="/profile">
                <Button variant="outline" className="w-full justify-start">
                  <Users className="h-4 w-4 mr-2" />
                  Update Profile
                </Button>
              </Link>
              <Link to="/matches">
                <Button variant="outline" className="w-full justify-start">
                  <Heart className="h-4 w-4 mr-2" />
                  Browse Matches
                </Button>
              </Link>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => toast.info("📅 Meeting scheduler coming soon!", {
                  description: "This feature will be available in the next update."
                })}
              >
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Meetings
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => toast.info("📊 Analytics dashboard coming soon!", {
                  description: "View detailed networking insights and performance metrics."
                })}
              >
                <TrendingUp className="h-4 w-4 mr-2" />
                View Analytics
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chat Dialog */}
      <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={selectedMatch?.avatar} alt={selectedMatch?.name} />
                <AvatarFallback>{selectedMatch?.name?.split(' ').map((n: string) => n[0]).join('')}</AvatarFallback>
              </Avatar>
              Chat with {selectedMatch?.name}
            </DialogTitle>
            <DialogDescription>
              {selectedMatch?.role} at {selectedMatch?.company} • {selectedMatch?.location}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-primary/5 border border-primary/20 p-3 rounded-lg">
              <p className="text-sm font-medium text-primary mb-1">AI Icebreaker Suggestion:</p>
              <p className="text-sm text-foreground">{selectedMatch?.icebreaker}</p>
            </div>
            
            <div className="h-64 border rounded-lg p-4 overflow-y-auto bg-gray-50">
              {mockChatMessages[selectedMatch?.id as keyof typeof mockChatMessages]?.map((msg, idx) => (
                <div key={idx} className={`mb-3 flex ${msg.sender === 'You' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-xs px-3 py-2 rounded-lg ${
                    msg.sender === 'You' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-white border text-foreground'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                    <p className={`text-xs mt-1 ${
                      msg.sender === 'You' ? 'text-primary-foreground/70' : 'text-muted-foreground'
                    }`}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Meeting Dialog */}
      <Dialog open={showMeetingDialog} onOpenChange={setShowMeetingDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Map className="h-5 w-5" />
              Suggest Meeting Location
            </DialogTitle>
            <DialogDescription>
              Choose a location to meet with {selectedMatch?.name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-sm text-foreground/70 flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Suggestions near {selectedMatch?.location}
            </div>
            
            <div className="space-y-2">
              {mockLocations[selectedMatch?.location as keyof typeof mockLocations]?.map((location, idx) => (
                <div
                  key={idx}
                  className="border rounded-lg p-3 hover:bg-primary/5 cursor-pointer transition-colors"
                  onClick={() => handleSelectMeetingLocation(location)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        {location.type === 'coffee' ? (
                          <Coffee className="h-4 w-4 text-amber-600" />
                        ) : (
                          <Clock className="h-4 w-4 text-green-600" />
                        )}
                        <h4 className="font-medium text-foreground">{location.name}</h4>
                      </div>
                      <p className="text-sm text-foreground/70 mt-1">{location.address}</p>
                      <div className="flex items-center gap-1 mt-1">
                        <span className="text-xs text-amber-600">★</span>
                        <span className="text-xs text-foreground/70">{location.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-xs text-foreground/50 text-center">
              💡 Tip: These locations are suggested based on proximity and ratings
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}