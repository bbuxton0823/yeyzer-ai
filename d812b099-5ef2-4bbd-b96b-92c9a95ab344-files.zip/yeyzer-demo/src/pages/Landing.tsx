import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Brain, 
  MapPin, 
  MessageSquare, 
  Sparkles, 
  ArrowRight,
  Shield,
  Target,
  Zap
} from 'lucide-react';

export function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-background">
      {/* Navigation */}
      <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-full bg-gradient-to-r from-primary to-primary/60 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              Yeyzer AI
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/login">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link to="/signup">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container py-24 md:py-32">
        <div className="flex flex-col items-center text-center space-y-8">
          <Badge variant="outline" className="px-4 py-2">
            <Brain className="h-4 w-4 mr-2" />
            AI-Powered Professional Matching
          </Badge>
          
          <h1 className="font-serif text-4xl font-light tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
            Meet Your Next{' '}
            <span className="bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
              Business Partner
            </span>
          </h1>
          
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground md:text-xl">
            Yeyzer AI analyzes your professional persona and connects you with the perfect matches for meaningful business relationships. From first chat to first meeting, we make networking effortless.
          </p>
          
          <div className="flex flex-col gap-4 sm:flex-row">
            <Link to="/signup">
              <Button size="lg" className="group">
                Start Matching <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </Button>
            </Link>
            <Button variant="outline" size="lg">
              See How It Works
            </Button>
          </div>
          
          <div className="flex items-center gap-8 pt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              <span>80% Match Success Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span>24h Response Time</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span>Privacy First</span>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-24 bg-muted/50">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            How Yeyzer AI Works
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Our AI analyzes your professional signals and matches you with compatible business partners
          </p>
        </div>
        
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardContent className="p-6 text-center space-y-4">
              <div className="h-12 w-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Profile Analysis</h3>
              <p className="text-sm text-muted-foreground">
                We analyze your LinkedIn, GitHub, and professional presence to understand your persona
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardContent className="p-6 text-center space-y-4">
              <div className="h-12 w-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                <Brain className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">AI Matching</h3>
              <p className="text-sm text-muted-foreground">
                Our algorithm finds professionals who complement your skills and goals
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardContent className="p-6 text-center space-y-4">
              <div className="h-12 w-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                <MessageSquare className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Smart Icebreakers</h3>
              <p className="text-sm text-muted-foreground">
                AI-generated conversation starters based on shared interests and goals
              </p>
            </CardContent>
          </Card>
          
          <Card className="border-2 hover:border-primary/20 transition-colors">
            <CardContent className="p-6 text-center space-y-4">
              <div className="h-12 w-12 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold">Meet In Person</h3>
              <p className="text-sm text-muted-foreground">
                Venue recommendations and scheduling to turn digital connections into real meetings
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container py-24">
        <div className="text-center space-y-8">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Ready to Transform Your Networking?
          </h2>
          <p className="mx-auto max-w-2xl text-muted-foreground">
            Join thousands of professionals who've found their perfect business matches with Yeyzer AI
          </p>
          <Link to="/signup">
            <Button size="lg" className="group">
              Get Started Now <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/50">
        <div className="container py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-6 w-6 rounded-full bg-gradient-to-r from-primary to-primary/60 flex items-center justify-center">
                <Sparkles className="h-3 w-3 text-primary-foreground" />
              </div>
              <span className="font-bold bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
                Yeyzer AI
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 Yeyzer Inc. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}